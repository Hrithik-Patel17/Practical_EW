export const Images = {
    imgDemo1: require('./demo1.png'),
    imgDemo2: require('./demo2.png'),
    imgDemo3: require('./demo3.png'),
    imgDemo4: require('./demo4.png'),
    imgDemo5: require('./demo5.png'),
    imgDemo6: require('./demo6.png'),
    imgDemo7: require('./demo7.png')
}
import { name as appName } from '../../app.json';

export const Strings = {
    welcome: `Welcome, ${appName}!`
}
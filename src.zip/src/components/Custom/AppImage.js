import React, { Component } from 'react';
import { Text, View } from 'react-native';

class AppImage extends Component {
	constructor(props) {
		super(props);
		this.state = {
		};
	}

	render() {
		return (
			<View>
				<Text> AppImage </Text>
			</View>
		);
	}
}

export default AppImage;

import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Modal, Image } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { Fonts, Icons } from '../../assets';
import AppIcon from './AppIcon';
import AppText from './AppText';
import AppSafeView from './AppSafeView';
import { AppContainer, AppMargin } from '../../constants/commonStyle';

const AppDropdown = ({ top, defaultTitle, selectedValue, onValueChange, options }) => {
	const [modalVisible, setModalVisible] = useState(false);
	const [currentValue, setCurrentValue] = useState(selectedValue || '');

	const showModal = () => {
		setModalVisible(true);
	};

	const hideModal = () => {
		setModalVisible(false);
	};

	const handleValueChange = (value) => {
		setCurrentValue(value);
		onValueChange(value);
	};

	return (
		<View style={{ marginTop: top ? top : 0 }}>
			<View style={{ flexDirection: 'row', alignItems: 'center' }}>
				<AppIcon icon={Icons.icnTranslate} />
				{defaultTitle && (
					<AppText left={AppMargin._10} onTextPress={showModal} label={defaultTitle} />
				)}
				{selectedValue && (
					<AppText
						fontFamily={Fonts.BOLD}
						left={AppMargin._10}
						onTextPress={showModal}
						label={currentValue}
					/>
				)}
			</View>

			<Modal visible={modalVisible} animationType="slide">
				<AppSafeView>
					<View style={AppContainer}>
						<AppText left={AppMargin._10} onTextPress={hideModal} label={'Done'} />
						<Picker selectedValue={currentValue} onValueChange={handleValueChange}>
							{options.map((option) => (
								<Picker.Item key={option.value} label={option.label} value={option.value} />
							))}
						</Picker>
					</View>
				</AppSafeView>
			</Modal>
		</View>
	);
};

export default AppDropdown;

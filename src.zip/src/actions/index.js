import * as dispatchData from "./dispatchData"

export const actionCreators = Object.assign({}, dispatchData)